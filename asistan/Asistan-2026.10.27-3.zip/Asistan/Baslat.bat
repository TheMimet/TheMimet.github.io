@echo off
chcp 65001 >nul
title Adliye Dosya Takip
cd /d "%~dp0"

if not exist "sunucu.ps1" (
  echo.
  echo   HATA: sunucu.ps1 bulunamadi.
  echo   Baslat.bat, sunucu.ps1 ve adliye-takip.html ayni klasorde olmali.
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sunucu.ps1"

if errorlevel 1 (
  echo.
  echo   Program baslatilamadi.
  echo   Bilgisayarinizda PowerShell kisitlanmis olabilir; yoneticinize danisin.
  echo.
  pause
)
