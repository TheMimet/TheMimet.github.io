# ============================================================
#  Adliye Dosya Takip - yerel sunucu
#  Kurulum gerektirmez. Veriyi kendi klasorundeki veri.json dosyasina yazar.
#  Yalnizca 127.0.0.1 (bu bilgisayar) dinler, disariya acilmaz.
# ============================================================

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$kok         = Split-Path -Parent $MyInvocation.MyCommand.Definition
$htmlYol     = Join-Path $kok "adliye-takip.html"
$veriYol     = Join-Path $kok "veri.json"
$yedekKlasor = Join-Path $kok "yedek"

if (-not (Test-Path $htmlYol)) {
    Write-Host ""
    Write-Host "  HATA: adliye-takip.html bulunamadi." -ForegroundColor Red
    Write-Host "  Bu dosya ile ayni klasorde olmali: $kok"
    Write-Host ""
    Read-Host "  Kapatmak icin Enter'a basin"
    exit 1
}
if (-not (Test-Path $yedekKlasor)) { New-Item -ItemType Directory -Path $yedekKlasor | Out-Null }

# ---- Internet isaretini (Mark of the Web) temizle ----
# Tarayiciyla indirilen Baslat.bat "Kisitli site" olarak isaretlenir ve
# Windows cift tiklamayla acilmasini engeller. Sunucu bir kez calistiginda
# bu isareti kaldiririz; sonraki acilislarda engel cikmaz.
foreach ($ad in @("Baslat.bat", "sunucu.ps1")) {
    $y = Join-Path $kok $ad
    if (Test-Path $y) { try { Unblock-File -LiteralPath $y -ErrorAction SilentlyContinue } catch { } }
}

$utf8 = New-Object System.Text.UTF8Encoding($false)

# ---- Bos port bul ----
$dinleyici = $null
$port = 0
foreach ($p in 8761..8790) {
    try {
        $d = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
        $d.Start()
        $dinleyici = $d; $port = $p
        break
    } catch { }
}
if (-not $dinleyici) {
    Write-Host "  HATA: Bos port bulunamadi (8761-8790)." -ForegroundColor Red
    Read-Host "  Kapatmak icin Enter'a basin"
    exit 1
}

$adres = "http://127.0.0.1:$port/"

Write-Host ""
Write-Host "  ============================================" -ForegroundColor DarkCyan
Write-Host "   ADLIYE DOSYA TAKIP" -ForegroundColor Cyan
Write-Host "  ============================================" -ForegroundColor DarkCyan
Write-Host ""
Write-Host "   Program calisiyor." -ForegroundColor Green
Write-Host "   Veri dosyasi : $veriYol"
Write-Host "   Adres        : $adres"
Write-Host ""
Write-Host "   Tarayici birazdan acilacak." -ForegroundColor Gray
Write-Host "   Isiniz bitince BU PENCEREYI KAPATIN." -ForegroundColor Yellow
Write-Host ""

Start-Process $adres | Out-Null

# ---- Yardimcilar ----
function Send-Response($stream, [int]$kod, [string]$tip, [byte[]]$govde, [string]$ekBaslik = "") {
    $durum = switch ($kod) { 200 { "OK" } 204 { "No Content" } 404 { "Not Found" } 500 { "Server Error" } default { "OK" } }
    $bas = "HTTP/1.1 $kod $durum`r`n"
    $bas += "Content-Type: $tip`r`n"
    $bas += "Content-Length: $($govde.Length)`r`n"
    $bas += "Cache-Control: no-store`r`n"
    $bas += "Connection: close`r`n"
    if ($ekBaslik) { $bas += "$ekBaslik`r`n" }
    $bas += "`r`n"
    $basBayt = [System.Text.Encoding]::ASCII.GetBytes($bas)
    $stream.Write($basBayt, 0, $basBayt.Length)
    if ($govde.Length -gt 0) { $stream.Write($govde, 0, $govde.Length) }
    $stream.Flush()
}

function Save-Veri([string]$icerik) {
    # Once gecici dosyaya yaz, sonra tasi: yazma yarida kalirsa mevcut veri bozulmaz
    $gecici = "$veriYol.tmp"
    [System.IO.File]::WriteAllText($gecici, $icerik, $utf8)
    if (Test-Path $veriYol) { Remove-Item $veriYol -Force }
    Move-Item $gecici $veriYol -Force

    # Gunluk yedek (gunde bir kez)
    $bugun = Get-Date -Format "yyyy-MM-dd"
    $yedek = Join-Path $yedekKlasor "veri-$bugun.json"
    if (-not (Test-Path $yedek)) {
        Copy-Item $veriYol $yedek -Force
        # 30 gunden eski yedekleri temizle
        Get-ChildItem $yedekKlasor -Filter "veri-*.json" |
            Sort-Object Name -Descending | Select-Object -Skip 30 |
            ForEach-Object { Remove-Item $_.FullName -Force }
    }
}

# ---- Istek dongusu ----
try {
    while ($true) {
        $istemci = $dinleyici.AcceptTcpClient()
        try {
            $istemci.ReceiveTimeout = 15000
            $istemci.SendTimeout = 15000
            $stream = $istemci.GetStream()

            # Basliklari oku (\r\n\r\n gorene kadar)
            $ms = New-Object System.IO.MemoryStream
            $buf = New-Object byte[] 4096
            $basSonu = -1
            while ($basSonu -lt 0) {
                $n = $stream.Read($buf, 0, $buf.Length)
                if ($n -le 0) { break }
                $ms.Write($buf, 0, $n)
                $tumu = $ms.ToArray()
                for ($i = 3; $i -lt $tumu.Length; $i++) {
                    if ($tumu[$i-3] -eq 13 -and $tumu[$i-2] -eq 10 -and $tumu[$i-1] -eq 13 -and $tumu[$i] -eq 10) {
                        $basSonu = $i + 1; break
                    }
                }
            }
            if ($basSonu -lt 0) { $istemci.Close(); continue }

            $tumu = $ms.ToArray()
            $basMetin = [System.Text.Encoding]::ASCII.GetString($tumu, 0, $basSonu)
            $satirlar = $basMetin -split "`r`n"
            $ilk = $satirlar[0] -split " "
            $yontem = $ilk[0]
            $yol = if ($ilk.Length -gt 1) { $ilk[1] } else { "/" }
            if ($yol.Contains("?")) { $yol = $yol.Substring(0, $yol.IndexOf("?")) }

            # Govde (varsa)
            $govdeMetin = ""
            $uzunluk = 0
            foreach ($s in $satirlar) {
                if ($s -match '^(?i)Content-Length:\s*(\d+)') { $uzunluk = [int]$Matches[1] }
            }
            if ($uzunluk -gt 0) {
                $govdeBayt = New-Object byte[] $uzunluk
                $mevcut = $tumu.Length - $basSonu
                if ($mevcut -gt 0) { [Array]::Copy($tumu, $basSonu, $govdeBayt, 0, [Math]::Min($mevcut, $uzunluk)) }
                $okunan = [Math]::Min($mevcut, $uzunluk)
                while ($okunan -lt $uzunluk) {
                    $n = $stream.Read($govdeBayt, $okunan, $uzunluk - $okunan)
                    if ($n -le 0) { break }
                    $okunan += $n
                }
                $govdeMetin = $utf8.GetString($govdeBayt, 0, $okunan)
            }

            # ---- Yonlendirme ----
            if ($yol -eq "/" -or $yol -eq "/index.html") {
                $html = [System.IO.File]::ReadAllBytes($htmlYol)
                Send-Response $stream 200 "text/html; charset=utf-8" $html
            }
            elseif ($yol -eq "/veri" -and $yontem -eq "GET") {
                $icerik = if (Test-Path $veriYol) { [System.IO.File]::ReadAllText($veriYol, $utf8) } else { "" }
                Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes($icerik)
            }
            elseif ($yol -eq "/veri" -and $yontem -eq "POST") {
                try {
                    if ($govdeMetin.Trim().Length -lt 2) { throw "Bos govde" }
                    # Ayni port araliginda birden fazla kurulum calisabilir. Istemci hangi
                    # klasore ait oldugunu bildirir; uyusmuyorsa yazma reddedilir. Aksi halde
                    # bir kurulumun acik sekmesi digerinin veri.json'una yazabilir.
                    $istemciKlasor = ""
                    foreach ($sh in $satirlar) {
                        if ($sh -match '^(?i)X-Klasor:\s*(.+)$') { $istemciKlasor = $Matches[1].Trim() }
                    }
                    # Baslik ZORUNLUDUR. Eski (guncellenmeden once acilmis) bir sekme
                    # baslik gondermez; onu da reddediyoruz, cunku hangi kuruluma ait
                    # oldugu bilinmeyen bir yazma en tehlikeli durumdur.
                    if ($istemciKlasor -ne $kok) {
                        $zaman = Get-Date -Format "HH:mm:ss"
                        $sebep = if ($istemciKlasor -eq "") { "eski sekme (klasor bildirmiyor)" } else { "baska kurulum" }
                        Write-Host "   [$zaman] REDDEDILDI - $sebep" -ForegroundColor Yellow
                        Send-Response $stream 409 "application/json; charset=utf-8" $utf8.GetBytes('{"ok":false,"hata":"Bu pencere bu kuruluma ait degil. Sekmeyi kapatip programi Baslat ile yeniden acin."}')
                        $istemci.Close(); continue
                    }
                    Save-Veri $govdeMetin
                    $zaman = Get-Date -Format "HH:mm:ss"
                    Write-Host "   [$zaman] kaydedildi  ($([Math]::Round($govdeMetin.Length/1024,1)) KB)" -ForegroundColor DarkGray
                    Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes('{"ok":true}')
                } catch {
                    $m = ($_.Exception.Message -replace '"', "'")
                    Send-Response $stream 500 "application/json; charset=utf-8" $utf8.GetBytes("{""ok"":false,""hata"":""$m""}")
                }
            }
            elseif ($yol -eq "/yedekler") {
                # Yedek klasorundeki dosyalari listeler (yalnizca okur)
                try {
                    $ler = @()
                    if (Test-Path $yedekKlasor) {
                        $ler = Get-ChildItem $yedekKlasor -Filter "veri-*.json" |
                               Sort-Object Name |
                               ForEach-Object { @{ ad = $_.Name; boyut = $_.Length } }
                    }
                    $c = (@{ ok = $true; dosyalar = @($ler) } | ConvertTo-Json -Compress -Depth 4)
                    Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes($c)
                } catch {
                    Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes('{"ok":false,"dosyalar":[]}')
                }
            }
            elseif ($yol -eq "/yedek") {
                # Tek bir yedegi dondurur. Ad disaridan geldigi icin klasor disina cikilamaz.
                try {
                    $ad = ""
                    if ($ilk.Length -gt 1 -and $ilk[1] -match "ad=([^&]+)") {
                        $ad = [System.Uri]::UnescapeDataString($Matches[1])
                    }
                    if ($ad -notmatch '^veri-\d{4}-\d{2}-\d{2}\.json$') { throw "Gecersiz yedek adi" }
                    $yol2 = Join-Path $yedekKlasor $ad
                    if (-not (Test-Path $yol2)) { throw "Yedek bulunamadi" }
                    $icerik = [System.IO.File]::ReadAllText($yol2, $utf8)
                    Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes($icerik)
                } catch {
                    $m3 = ($_.Exception.Message -replace '"', "'")
                    Send-Response $stream 404 "application/json; charset=utf-8" $utf8.GetBytes("{""ok"":false,""hata"":""$m3""}")
                }
            }
            elseif ($yol -eq "/kisayol" -and $yontem -eq "POST") {
                try {
                    $masa = [Environment]::GetFolderPath("Desktop")
                    $batYol = Join-Path $kok "Baslat.bat"
                    if (-not (Test-Path $batYol)) { throw "Baslat.bat bulunamadi" }

                    # Simge: HTML icindeki gomulu logoyu cikarip .ico'ya cevir
                    $icoYol = Join-Path $kok "Asistan.ico"
                    if (-not (Test-Path $icoYol)) {
                        $htmlMetin = [System.IO.File]::ReadAllText($htmlYol, $utf8)
                        $m = [regex]::Match($htmlMetin, 'class="mark" src="data:image/png;base64,([A-Za-z0-9+/=]+)"')
                        if ($m.Success) {
                            $png = [Convert]::FromBase64String($m.Groups[1].Value)
                            # ICONDIR + ICONDIRENTRY + PNG (Vista+ PNG gomulu ico destekler)
                            $ico = New-Object System.IO.MemoryStream
                            $bw  = New-Object System.IO.BinaryWriter($ico)
                            $bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]1)
                            $bw.Write([Byte]72); $bw.Write([Byte]72); $bw.Write([Byte]0); $bw.Write([Byte]0)
                            $bw.Write([UInt16]1); $bw.Write([UInt16]32)
                            $bw.Write([UInt32]$png.Length); $bw.Write([UInt32]22)
                            $bw.Write($png); $bw.Flush()
                            [System.IO.File]::WriteAllBytes($icoYol, $ico.ToArray())
                            $bw.Dispose(); $ico.Dispose()
                        }
                    }

                    $lnk = Join-Path $masa "Asistan.lnk"
                    $ws  = New-Object -ComObject WScript.Shell
                    $ks  = $ws.CreateShortcut($lnk)
                    $ks.TargetPath       = $batYol
                    $ks.WorkingDirectory = $kok
                    $ks.Description      = "Adliye Dosya Takip"
                    if (Test-Path $icoYol) { $ks.IconLocation = "$icoYol,0" }
                    $ks.Save()

                    $zaman = Get-Date -Format "HH:mm:ss"
                    Write-Host "   [$zaman] Masaustune kisayol olusturuldu: $lnk" -ForegroundColor Green
                    $c = (@{ ok = $true; yol = $lnk } | ConvertTo-Json -Compress)
                    Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes($c)
                } catch {
                    $m2 = ($_.Exception.Message -replace '"', "'")
                    Send-Response $stream 500 "application/json; charset=utf-8" $utf8.GetBytes("{""ok"":false,""hata"":""$m2""}")
                }
            }
            elseif ($yol -eq "/durum") {
                $bilgi = @{ ok = $true; klasor = $kok; veriDosyasi = $veriYol; sunucu = $true } | ConvertTo-Json -Compress
                Send-Response $stream 200 "application/json; charset=utf-8" $utf8.GetBytes($bilgi)
            }
            else {
                Send-Response $stream 404 "text/plain; charset=utf-8" $utf8.GetBytes("Bulunamadi")
            }
        } catch {
            # tek bir istegin hatasi sunucuyu durdurmasin
        } finally {
            try { $istemci.Close() } catch { }
        }
    }
} finally {
    try { $dinleyici.Stop() } catch { }
}
